function clickThis() {
console.log('test');
}
