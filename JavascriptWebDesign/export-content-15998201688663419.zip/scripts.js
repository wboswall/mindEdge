   var person = { 
            name: "George", 
            profession : "actor", 
            home : "California", 
            personDetails : function() { 
            return this.name + " is an " + this.profession  
                              + " from " + this.home + " "; 
                      } 
                  }
           document.getElementById("p1").innerHTML  
                          = person.personDetails(); 
